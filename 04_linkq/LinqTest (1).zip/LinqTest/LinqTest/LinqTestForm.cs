﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LinqTest
{
    public partial class LinqTestForm : Form
    {
        private static string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
        private static int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
        public LinqTestForm()
        {
            InitializeComponent();
        }

        [Description("Posortowane słowa")]
        public static void Test_AB_01(StringBuilder sb)
        {
            digits.OrderBy(word => word).Aggregate(sb, (sb_, word) => sb.Append(word).Append(' '));
        }

        [Description("Cyfry słownie")]
        public static void Test_AB_02(StringBuilder sb)
        {
            numbers.Select(digit => digits[digit]).Aggregate(sb, (sb_, word) => sb.Append(word).Append(' '));
        }

        [Description("Tablica potęg")]
        public static void Test_AB_03(StringBuilder sb)
        {
            var table = from n in numbers orderby n select new { n, n2 = n * n, n3 = n * n * n };
            foreach (var row in table) sb.AppendFormat("{0}\t{1}\t{2}",row.n,row.n2,row.n3).AppendLine();
        }

        private void BtnExecute_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            Test_AB_01(sb);
            sb.AppendLine();
            Test_AB_02(sb);
            sb.AppendLine();
            Test_AB_03(sb);
            sb.AppendLine();
            TbLog.Text = sb.ToString();
        }
    }
}
